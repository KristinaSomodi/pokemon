"use strict";

//https://pokeapi.co/

const allPokemon = [];
const search = document.querySelector("#search");

//funkcija koja ce dohvacati sa servera podatke

const getPokemon = async () => {
  for (let i = 1; i <= 21; i++) {
    //const URL sa apijem
    const baseURL = `https://pokeapi.co/api/v2/pokemon/${i}`;
    //response varijablu, u njoj zovemo fetch() => Promise
    const response = await fetch(baseURL)
      //.then() => response koji pretvaramo u json() da ga mozemo iscitati => Promise
      .then((response) => response.json());
    allPokemon.push(response);
  }
  //uzimanje data, transform response
  Promise.all(allPokemon).then((data) => {
    const pokemon = data.map((item) => ({
      name: item.name,
      id: item.id,
      image: item.sprites["front_default"],
      color: item.types[0].type["name"],
    }));
    console.log(pokemon);
    showCards(pokemon);
    btn.addEventListener("click", function () {
      sortPoke(pokemon);
    });
  });
};

getPokemon();

const content = document.querySelector(".content");

function showCards(pokemons) {
  let cards = pokemons
    .map(
      (pokemon) => `
    <div class="content__card color--${pokemon.color}">
    <div class="content__card__top">
      <div class="content__card__name">${pokemon.name}</div>
      <div class="content__card__num">#${pokemon.id}</div>
    </div>
    <div class="content__card__bottom">
      <img class="content__card__image" src="${pokemon.image}">
      <i class="icon icon--pokeball"></i>
    </div>
    </div>
      `
    )
    .join("");
  content.innerHTML = cards;
}

// const myFunction = (pokemoni) => {};

let order = false;

function sortPoke(pokemons) {
  order = !order;
  let sortedPoke = pokemons.sort(function (a, b) {
    let nameA = a.name.toUpperCase();
    let nameB = b.name.toUpperCase();
    return nameA > nameB && -1;
  });
  showCards(order ? sortedPoke : sortedPoke.reverse());
}

const btn = document.querySelector(".btn");
